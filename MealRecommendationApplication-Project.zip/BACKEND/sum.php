<?php 
  $a =5;
  echo "AAAAA";
  echo $a;

?>

